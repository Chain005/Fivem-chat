Config = {}

Config.OnlyFirstname = false
Config.EnableESXIdentity = true