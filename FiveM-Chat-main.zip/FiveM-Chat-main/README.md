# FiveM-Chat

This is a beautiful chat that does all of the normal chat functions.

This chat was specially created by me for the FiveM community

Install:
-Chat resource in your resource folder under gameplay move and replace.

The style of the chat is possible in the CSS as well as changing the color of the chat


![Screenshot_7](https://user-images.githubusercontent.com/87772503/131379124-075b0aeb-dafd-4318-af32-cac4fbae84c9.png)

